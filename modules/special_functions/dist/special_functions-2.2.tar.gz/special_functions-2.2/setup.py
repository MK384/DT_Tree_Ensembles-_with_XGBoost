from setuptools import setup


setup(
    name='special_functions',
    version='2.2',
    description= 'the helper specialized functions used in the main algorithm of the DT',
    author= 'Mohammed Khaled',
    author_email='mohammed.kh384@gmail.com',
    url='github.com\\mk384',
    py_modules=['special_functions']
)
